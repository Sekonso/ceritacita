import { html } from "lit";
import { msg, str, updateWhenLocaleChanges } from "@lit/localize";
import LitWithoutShadowDom from "./base/LitWithoutShadowDom";

class StoryModal extends LitWithoutShadowDom {
  static properties = {
    story: { type: Object },
  };

  constructor() {
    super();
    updateWhenLocaleChanges(this);

    this.story = {
      id: undefined,
      name: undefined,
      description: undefined,
      photoUrl: undefined,
      createdAt: undefined,
    };
  }

  render() {
    return html`
      <div
        class="modal fade"
        id="exampleModal"
        tabindex="-1"
        aria-labelledby="exampleModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
          <div class="modal-content">
            <div class="modal-header">
              <h1 class="modal-title fs-5" id="exampleModalLabel">${msg(`Detail cerita`)}</h1>
            </div>
            <div class="modal-body">
              <img
                src=${this.story.photoUrl}
                class="card-img-top mb-2"
                alt="${this.story.name}'s image"
                loading="lazy"
              />
              <h2>${this.story.name}</h2>
              <p class="badge text-bg-secondary px-2">
                ${msg(str`Dibuat pada tanggal: ${this._convertTime(this.story.createdAt)}`)}
              </p>
              <p>${this.story.description}</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-bs-dismiss="modal">
                ${msg(`Tutup`)}
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  _convertTime(timestamp) {
    const date = new Date(timestamp);

    const options = {
      day: "numeric",
      month: "numeric",
      year: "numeric",
    };

    return date.toLocaleDateString("id-ID", options);
  }
}

customElements.define("story-modal", StoryModal);
