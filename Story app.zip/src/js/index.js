import "../sass/main.scss";
import * as bootstrap from "bootstrap";
import "./components/index";
