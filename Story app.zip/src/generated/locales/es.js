
    // Do not modify this file by hand!
    // Re-generate this file by running lit-localize

    
    import {str} from '@lit/localize';

    /* eslint-disable no-irregular-whitespace */
    /* eslint-disable @typescript-eslint/no-explicit-any */

    export const templates = {
      's1e2ab5ddaa5585fc': `Ver detalle`,
's2ba2f8aa54e220db': `Mi nombre es Adriansyah, soy estudiante de Ingeniería Informática en la Universidad de Pamulang.
        En este proyecto, creé una aplicación web llamada "CeritaCita" para compartir historias entre usuarios.
        Esta aplicación fue creada para cumplir con uno de los requisitos para graduarse de la clase de Dicoding
        "Aprender herramientas front-end intermedias".`,
's2d34e59b6e0f37d8': `Ingresa la descripción de tu historia...`,
's347024ed1f8c841b': `Lista de Historias`,
's392e857053d5b3fd': `Imagen`,
's4b4c497a409d757e': str`Creado en: ${0}`,
's5fae657c633254f7': `Idioma`,
's749c72374d54863f': `Cerrar`,
's772ce5f935d58e37': `descripción`,
's790d2be79cd3642c': `La descripción debe estar completada.`,
'sae4cacfadda16c46': `Agrega tu historia`,
'sd17821dcb6ba2ff9': `Perfil del Desarrollador`,
'sdb29f7e6769ceb0f': `Se debe seleccionar una imagen.`,
'seab46c9dc339f63f': `Enviar`,
'sf29c187d9a394976': `Detalle de la historia`,
    };
  