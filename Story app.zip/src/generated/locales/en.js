
    // Do not modify this file by hand!
    // Re-generate this file by running lit-localize

    
    import {str} from '@lit/localize';

    /* eslint-disable no-irregular-whitespace */
    /* eslint-disable @typescript-eslint/no-explicit-any */

    export const templates = {
      's1e2ab5ddaa5585fc': `See detail`,
's2ba2f8aa54e220db': `My name is Adriansyah, I am a student of Informatics Engineering at Pamulang University.
        In this project, I created a website application called "CeritaCita" to share stories among users.
        This application was created to fulfill one of the requirements for graduating from the Dicoding class
        "Learn intermediate front-end tools."`,
's2d34e59b6e0f37d8': `Enter your story description...`,
's347024ed1f8c841b': `Story List`,
's392e857053d5b3fd': `Image`,
's4b4c497a409d757e': str`Created on: ${0}`,
's5fae657c633254f7': `Language`,
's749c72374d54863f': `Close`,
's772ce5f935d58e37': `Description`,
's790d2be79cd3642c': `Description must be filled in.`,
'sae4cacfadda16c46': `Add Your Story`,
'sd17821dcb6ba2ff9': `Developer Profile`,
'sdb29f7e6769ceb0f': `An image must be selected.`,
'seab46c9dc339f63f': `Submit`,
'sf29c187d9a394976': `Story detail`,
    };
  